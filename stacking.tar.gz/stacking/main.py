import os
import time
from siamese import Model
import tensorflow as tf
from utils import pp 
import scipy.io as sio
import scipy.misc
from scipy.ndimage import gaussian_filter
import numpy as np
import math
import time
import pdb

flags =tf.app.flags
flags.DEFINE_integer("epochs", 2000000,"Epoch to train")
flags.DEFINE_float("learning_rate",0.0001,"learning_rate for training")
flags.DEFINE_integer("image_wid",32,"cropping size")
flags.DEFINE_integer("image_hei",32,"cropping size")
flags.DEFINE_string("dataset","vertical","the name of training name")
flags.DEFINE_string("checkpoint_dir","checkpoint","the name to save the training network")
flags.DEFINE_string("output","output","The directory name to testset output image ")
flags.DEFINE_integer("batch_size",16,"batch_size")
flags.DEFINE_boolean("is_train",False,"True for training,False for testing")
flags.DEFINE_float("gpu",0.5,"GPU fraction per process")
FLAGS = flags.FLAGS

def main(_):
	date = time.strftime('%d%m')
	pp.pprint(flags.FLAGS.__flags)
	if not os.path.exists(FLAGS.checkpoint_dir):
        	os.makedirs(FLAGS.checkpoint_dir)
	if not os.path.exists(FLAGS.output):
        	os.makedirs(FLAGS.output)
    	if not os.path.exists(os.path.join('./logs',date)):
		os.makedirs(os.path.join('./logs',date))
    	gpu_config = tf.GPUOptions(per_process_gpu_memory_fraction=FLAGS.gpu)
    	with tf.Session(config=tf.ConfigProto(gpu_options=gpu_config)) as sess:
		if FLAGS.is_train:
        		LFSR = Model(sess,date, image_wid=FLAGS.image_wid,image_hei =FLAGS.image_hei ,batch_size=FLAGS.batch_size,\
	        	dataset_name=FLAGS.dataset, checkpoint_dir=FLAGS.checkpoint_dir)
			LFSR.train(FLAGS)
		else:
        		LFSR = Model(sess,date, image_wid=None ,image_hei = None ,batch_size=FLAGS.batch_size,\
	        	dataset_name=FLAGS.dataset, checkpoint_dir=FLAGS.checkpoint_dir)
			if LFSR.loadnet(FLAGS.checkpoint_dir):
				print('Load pretrained network \n')
			else:
				print('Fail to Load network \n')
			testdata = sio.loadmat('/research2/iccv2015/HCI_val_%s_input.mat'%FLAGS.dataset)
			test_input = testdata['LF_input']
			testdata = sio.loadmat('/research2/iccv2015/HCI_val_%s_gt.mat'%FLAGS.dataset)
			test_gt = testdata['LF_label']
			ssim_val = 0.0
			psnr_val = 0.0
			for ii in range(test_input.shape[-1]):
				test = np.array(test_input[0,ii]).astype(np.float32)/255.0
				test = np.reshape(test,(1,test.shape[0],test.shape[1],2))
				start_time = time.time()
	                	output = sess.run(LFSR.output, feed_dict={LFSR.train_input:test})
				end_time = time.time()-start_time
			        output = np.squeeze(output)
				label = test_gt[0,ii]
				label = np.squeeze(label)
				pixel =5
				output = output[pixel:-pixel,pixel:-pixel]
				label = label[pixel:-pixel,pixel:-pixel]
				#scipy.misc.imsave(os.path.join('output','predict_%04d.png' %ii),np.uint8(output*255.0))
				scipy.misc.imsave(os.path.join('output','predict_%04d.png' %ii),output)
				scipy.misc.imsave(os.path.join('output','gt_%04d.png' %ii),np.uint8(label))
				ssim_val += ssim_exact(label.astype(float)/255.0,output)
				psnr_val += psnr(label,np.uint8(output*255))			
				print('Test processing %d/%d time:%f \n' %(ii,test_input.shape[-1],end_time))
			mean_ssim = ssim_val/test_input.shape[-1]	
			mean_psnr = psnr_val/test_input.shape[-1]	
			print('mean psnr: %.6f mean ssim: %.6f \n' %(mean_psnr,mean_ssim))

def ssim_exact(img1, img2, sd=1.5, C1=0.01**2, C2=0.03**2):

    mu1 = gaussian_filter(img1, sd)
    mu2 = gaussian_filter(img2, sd)
    mu1_sq = mu1 * mu1
    mu2_sq = mu2 * mu2
    mu1_mu2 = mu1 * mu2
    sigma1_sq = gaussian_filter(img1 * img1, sd) - mu1_sq
    sigma2_sq = gaussian_filter(img2 * img2, sd) - mu2_sq
    sigma12 = gaussian_filter(img1 * img2, sd) - mu1_mu2

    ssim_num = ((2 * mu1_mu2 + C1) * (2 * sigma12 + C2))

    ssim_den = ((mu1_sq + mu2_sq + C1) * (sigma1_sq + sigma2_sq + C2))

    ssim_map = ssim_num / ssim_den
    return np.mean(ssim_map)

def psnr(img1,img2):
	mse = np.mean((img1-img2)**2)
	if mse ==0:
		return 100
	PIXEL_MAX = 255.0
	return 20 * math.log10(PIXEL_MAX / math.sqrt(mse))

if __name__=='__main__':
	tf.app.run()
