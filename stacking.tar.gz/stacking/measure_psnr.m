clear all
close all
gts = dir('output/gt_*.png');
outputs = dir('output/predict_*.png');
s= 0.0;
for i =1:length(gts)
   gt = imread(fullfile('output',gts(i).name)); 
   output = imread(fullfile('output',outputs(i).name));
    gt = gt(5:end-5);
    output = output(5:end-5);
    p = psnr(output,gt);
    s = s+p;
end