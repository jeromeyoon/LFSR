import os
import time
from glob import glob
import numpy as np
from numpy import inf
import tensorflow as tf
import pdb
import scipy.io as sio
from utils import *
from ops import *
class Model(object):
	def __init__(self,sess,date,image_wid=64,image_hei=64,batch_size=32,dataset_name='default',checkpoint_dir=None):
		self.sess = sess
		self.batch_size = batch_size
		self.dataset_name = dataset_name
		self.checkpoint_dir = checkpoint_dir
		self.image_wid = image_wid
		self.image_hei = image_hei
		self.LF_wid = 768
		self.LF_hei = 768
		self.count = 0
		self.date =date
		self.build_model()
	def build_model(self):
		
		self.train_input = tf.placeholder(tf.float32,[self.batch_size,self.image_hei,self.image_wid,2],name ='train_input')
		self.train_gt = tf.placeholder(tf.float32,[self.batch_size,self.image_hei,self.image_wid,1],name ='train_gt')
		self.output = self.stack_net(self.train_input)
		
		self.loss = tf.reduce_mean(tf.square(tf.sub(self.output,self.train_gt)))# MSE
		self.saver = tf.train.Saver(max_to_keep=1)
	def train(self,config):
		global_step = tf.Variable(0,name='global_step_train',trainable=False)	
		t_vars = tf.trainable_variables()
	        self.var_list1 = [var for var in t_vars if 'first_two_' in var.name]
	        self.var_list2 = [var for var in t_vars if 'last'  in var.name]
		train_optim1 = tf.train.GradientDescentOptimizer(config.learning_rate).minimize(self.loss,global_step=global_step,var_list=self.var_list1)
		train_optim2 = tf.train.GradientDescentOptimizer(0.00001).minimize(self.loss,global_step=global_step,var_list=self.var_list2)
		train_op = tf.group(train_optim1,train_optim2)
		tf.initialize_all_variables().run()

		# Load training data
		print('Load training data \n')
		traindata = sio.loadmat('/research2/iccv2015/HCI_train_vertical_input.mat')
		train_input = traindata['LF_input']
		traindata = sio.loadmat('/research2/iccv2015/HCI_train_vertical_gt.mat')
		train_gt = traindata['LF_label']
		batch_idxs = train_input.shape[-1]/config.batch_size
		valdata = sio.loadmat('/research2/iccv2015/HCI_val_vertical_input.mat')
		val_input = valdata['LF_input']
		valdata = sio.loadmat('/research2/iccv2015/HCI_val_vertical_gt.mat')
		val_gt = valdata['LF_label']
		val_batch_idxs = val_input.shape[-1]/config.batch_size
		#load trained network
		if self.loadnet(self.checkpoint_dir):
			print('Load pretrained network')
		else:
			print(' Load Fail!!')
		for epoch in xrange(config.epochs):
			rand_idx = np.random.permutation(range(train_input.shape[-1]))
			sum_train_MSE = 0.0
			sum_val_MSE =0.0
			for idx in xrange(0,batch_idxs):
				if epoch ==0:
					f_train_epoch = open(os.path.join("logs",self.date,'train_epoch.log'),'w')
					f_val = open(os.path.join("logs",self.date,'val.log'),'w')
				else:
					f_train_epoch = open(os.path.join("logs",self.date,'train_epoch.log'),'aw')
					f_val = open(os.path.join("logs",self.date,'val.log'),'aw')

				batch_files = rand_idx[idx*config.batch_size:(idx+1)*config.batch_size]	
				batches =[get_image(train_input[0,batch],train_gt[0,batch],self.image_wid) for batch in batch_files]
				batches = np.array(batches).astype(np.float32)
				input_ = batches[:,:,:,:2]
				gt = batches[:,:,:,2]
				gt = np.expand_dims(gt,axis=-1)
				 
				_,MSE = self.sess.run([train_op,self.loss],feed_dict={self.train_input:input_,self.train_gt:gt})
				self.count +=1
				sum_train_MSE +=MSE
				print('Epoch train[%2d] [%4d/%4d] MSE: %.4f \n' %(epoch,idx,batch_idxs,MSE))
		
			#Validation
			for val_idx in xrange(0,val_batch_idxs):		
				batch_files = range(val_input.shape[-1])[val_idx*config.batch_size:(val_idx+1)*config.batch_size]	
				batches =[get_image(val_input[0,batch],val_gt[0,batch],self.image_wid) for batch in batch_files]
				batches = np.array(batches).astype(float)
				
				input_ = batches[:,:,:,:2]
				gt = batches[:,:,:,2]
				gt = np.expand_dims(gt,axis=-1)

				MSE = self.sess.run([self.loss],feed_dict={self.train_input:input_,self.train_gt:gt})
				print('Epoch val[%2d] MSE: %.4f \n' %(epoch,MSE[0]))
				sum_val_MSE +=MSE[0]
			if np.mod(epoch,100) ==0:
				f_train_epoch.write('epoch %06d mean_MSE %.6f \n' %(epoch, sum_train_MSE/np.float(batch_idxs)))
				f_train_epoch.close()
				f_val.write('epoch %06d MSE %.6f \n' %(epoch, sum_val_MSE/np.float(val_batch_idxs)))
				f_val.close()	
	                    	self.save(config.checkpoint_dir,0)
	
	def stack_net(self,input_):
		h1 = conv2d(input_,64,k_h=9,k_w=9,d_h=1,d_w=1,padding='SAME',name='first_two_1')
		h1 = tf.nn.relu(h1)
		h2 = conv2d(h1,32,k_h=5,k_w=5,d_h=1,d_w=1,padding='SAME',name='first_two_2' )
		h2 = tf.nn.relu(h2)
		h3 = conv2d(h2,1,k_h=5,k_w=5,d_h=1,d_w=1,padding='SAME',name='last')
		return h3
	
	def loadnet(self,checkpoint_dir):
		model_dir = '%s' %(self.dataset_name)
		checkpoint_dir = os.path.join(checkpoint_dir,model_dir)
		ckpt = 	tf.train.get_checkpoint_state(checkpoint_dir)
		if ckpt and ckpt.model_checkpoint_path:
			ckpt_name = os.path.basename(ckpt.model_checkpoint_path)
			self.saver.restore(self.sess,os.path.join(checkpoint_dir,ckpt_name))	
			return True
		else:
			return False
	def save(self, checkpoint_dir, step):
        	model_name = "DCGAN.model"
	        model_dir = "%s" % (self.dataset_name)
	        #model_dir = "%s_%s" % (self.dataset_name, self.batch_size)
        	checkpoint_dir = os.path.join(checkpoint_dir, model_dir)

	        if not os.path.exists(checkpoint_dir):
        	    os.makedirs(checkpoint_dir)

	        self.saver.save(self.sess,
                        os.path.join(checkpoint_dir, model_name),global_step=step)

