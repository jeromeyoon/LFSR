import os
import numpy as np
import scipy.io as sio

def load_traindata():
	# Load training data
	print('Load training data \n')
	################## Vertical ###################
	traindata = sio.loadmat('/research2/SPL/HCI/fine-tune/training_data/HCI_train_vertical_finetune_input_1.mat')
	train_input_vertical1 = traindata['LF_input']
	traindata = sio.loadmat('/research2/SPL/HCI/fine-tune/training_data/HCI_train_vertical_finetune_input_2.mat')
	train_input_vertical2 = traindata['LF_input']
	train_input_vertical= np.concatenate([train_input_vertical1,train_input_vertical2],axis=-1)
	
	traindata = sio.loadmat('/research2/SPL/HCI/fine-tune/training_data/HCI_train_vertical_finetune_SR_gt_1.mat')
	train_gt_vertical1 = traindata['LF_SR']
	traindata = sio.loadmat('/research2/SPL/HCI/fine-tune/training_data/HCI_train_vertical_finetune_SR_gt_2.mat')
	train_gt_vertical2 = traindata['LF_SR']
	train_vertical_sr_gt= np.concatenate([train_gt_vertical1,train_gt_vertical2],axis=-1)
	
	traindata = sio.loadmat('/research2/SPL/HCI/fine-tune/training_data/HCI_train_vertical_finetune_ANG_gt_1.mat')
	train_gt_vertical1 = traindata['LF_ANG']
	traindata = sio.loadmat('/research2/SPL/HCI/fine-tune/training_data/HCI_train_vertical_finetune_ANG_gt_2.mat')
	train_gt_vertical2 = traindata['LF_ANG']
	train_vertical_ang_gt= np.concatenate([train_gt_vertical1,train_gt_vertical2],axis=-1)
	################## Horizontal ###################
	traindata = sio.loadmat('/research2/SPL/HCI/fine-tune/training_data/HCI_train_horizontal_finetune_input_1.mat')
	train_input_horizontal1 = traindata['LF_input']
	traindata = sio.loadmat('/research2/SPL/HCI/fine-tune/training_data/HCI_train_horizontal_finetune_input_2.mat')
	train_input_horizontal2 = traindata['LF_input']
	train_input_horizontal= np.concatenate([train_input_horizontal1,train_input_horizontal2],axis=-1)
	
	traindata = sio.loadmat('/research2/SPL/HCI/fine-tune/training_data/HCI_train_horizontal_finetune_SR_gt_1.mat')
	train_gt_horizontal1 = traindata['LF_SR']
	traindata = sio.loadmat('/research2/SPL/HCI/fine-tune/training_data/HCI_train_horizontal_finetune_SR_gt_2.mat')
	train_gt_horizontal2 = traindata['LF_SR']
	train_horizontal_sr_gt= np.concatenate([train_gt_horizontal1,train_gt_horizontal2],axis=-1)
	
	traindata = sio.loadmat('/research2/SPL/HCI/fine-tune/training_data/HCI_train_horizontal_finetune_ANG_gt_1.mat')
	train_gt_horizontal1 = traindata['LF_ANG']
	traindata = sio.loadmat('/research2/SPL/HCI/fine-tune/training_data/HCI_train_horizontal_finetune_ANG_gt_2.mat')
	train_gt_horizontal2 = traindata['LF_ANG']
	train_horizontal_ang_gt= np.concatenate([train_gt_horizontal1,train_gt_horizontal2],axis=-1)

	################## 4 views ###################

	traindata = sio.loadmat('/research2/SPL/HCI/fine-tune/training_data/HCI_train_4views_finetune_input_1.mat')
	train_input_4views1 = traindata['LF_input']
	traindata = sio.loadmat('/research2/SPL/HCI/fine-tune/training_data/HCI_train_4views_finetune_input_2.mat')
	train_input_4views2 = traindata['LF_input']
	traindata = sio.loadmat('/research2/SPL/HCI/fine-tune/training_data/HCI_train_4views_finetune_input_3.mat')
	train_input_4views3 = traindata['LF_input']
	train_input_4views= np.concatenate([train_input_4views1,train_input_4views2,train_input_4views3],axis=-1)
	
	traindata = sio.loadmat('/research2/SPL/HCI/fine-tune/training_data/HCI_train_4views_finetune_SR_gt_1.mat')
	train_gt_4views1 = traindata['LF_SR']
	traindata = sio.loadmat('/research2/SPL/HCI/fine-tune/training_data/HCI_train_4views_finetune_SR_gt_2.mat')
	train_gt_4views2 = traindata['LF_SR']
	traindata = sio.loadmat('/research2/SPL/HCI/fine-tune/training_data/HCI_train_4views_finetune_SR_gt_3.mat')
	train_gt_4views3 = traindata['LF_SR']
	train_4views_sr_gt= np.concatenate([train_gt_4views1,train_gt_4views2,train_gt_4views3],axis=-1)
	
	traindata = sio.loadmat('/research2/SPL/HCI/fine-tune/training_data/HCI_train_4views_finetune_ANG_gt_1.mat')
	train_gt_4views1 = traindata['LF_ANG']
	traindata = sio.loadmat('/research2/SPL/HCI/fine-tune/training_data/HCI_train_4views_finetune_ANG_gt_2.mat')
	train_gt_4views2 = traindata['LF_ANG']
	traindata = sio.loadmat('/research2/SPL/HCI/fine-tune/training_data/HCI_train_4views_finetune_ANG_gt_3.mat')
	train_gt_4views3 = traindata['LF_ANG']
	train_4views_ang_gt= np.concatenate([train_gt_4views1,train_gt_4views2,train_gt_4views3],axis=-1)


	return train_input_vertical,train_input_horizontal,train_input_4views,train_vertical_sr_gt,train_horizontal_sr_gt,train_4views_sr_gt,train_vertical_ang_gt,train_horizontal_ang_gt,train_4views_ang_gt

def load_valdata():
	valdata = sio.loadmat('/research2/SPL/HCI/fine-tune/training_data/HCI_val_vertical_finetune_input.mat')
	val_input_vertical = valdata['LF_input']
	valdata = sio.loadmat('/research2/SPL/HCI/fine-tune/training_data/HCI_val_vertical_finetune_SR_gt.mat')
	val_vertical_sr_gt = valdata['LF_SR']
	valdata = sio.loadmat('/research2/SPL/HCI/fine-tune/training_data/HCI_val_vertical_finetune_ANG_gt.mat')
	val_vertical_ang_gt = valdata['LF_ANG']

	valdata = sio.loadmat('/research2/SPL/HCI/fine-tune/training_data/HCI_val_horizontal_finetune_input.mat')
	val_input_horizontal = valdata['LF_input']
	valdata = sio.loadmat('/research2/SPL/HCI/fine-tune/training_data/HCI_val_horizontal_finetune_SR_gt.mat')
	val_horizontal_sr_gt = valdata['LF_SR']
	valdata = sio.loadmat('/research2/SPL/HCI/fine-tune/training_data/HCI_val_horizontal_finetune_ANG_gt.mat')
	val_horizontal_ang_gt = valdata['LF_ANG']

	valdata = sio.loadmat('/research2/SPL/HCI/fine-tune/training_data/HCI_val_4views_finetune_input.mat')
	val_input_4views = valdata['LF_input']
	valdata = sio.loadmat('/research2/SPL/HCI/fine-tune/training_data/HCI_val_4views_finetune_SR_gt.mat')
	val_4views_sr_gt = valdata['LF_SR']
	valdata = sio.loadmat('/research2/SPL/HCI/fine-tune/training_data/HCI_val_4views_finetune_ANG_gt.mat')
	val_4views_ang_gt = valdata['LF_ANG']
	return val_input_vertical,val_input_horizontal,val_input_4views,val_vertical_sr_gt,val_horizontal_sr_gt,val_4views_sr_gt,val_vertical_ang_gt,val_horizontal_ang_gt,val_4views_ang_gt

def load_testdata():
	valdata = sio.loadmat('/research2/SPL/HCI/fine-tune/training_data/HCI_val_vertical_finetune_ycbcr_input.mat')
	val_input_vertical = valdata['LF_input']
	"""
	valdata = sio.loadmat('/research2/SPL/HCI/fine-tune/training_data/HCI_val_vertical_finetune_ycbcr_ANG_gt.mat')
	val_vertical_ang_gt = valdata['LF_ANG']
	"""
	valdata = sio.loadmat('/research2/SPL/HCI/fine-tune/training_data/HCI_val_horizontal_finetune_ycbcr_input.mat')
	val_input_horizontal = valdata['LF_input']
	"""
	valdata = sio.loadmat('/research2/SPL/HCI/fine-tune/training_data/HCI_val_horizontal_finetune_ycbcr_ANG_gt.mat')
	val_horizontal_ang_gt = valdata['LF_ANG']
	"""
	valdata = sio.loadmat('/research2/SPL/HCI/fine-tune/training_data/HCI_val_4views_finetune_ycbcr_input.mat')
	val_input_4views = valdata['LF_input']
	"""
	valdata = sio.loadmat('/research2/SPL/HCI/fine-tune/training_data/HCI_val_4views_finetune_ycbcr_ANG_gt.mat')
	val_4views_ang_gt = valdata['LF_ANG']
	"""
	return val_input_vertical,val_input_horizontal,val_input_4views


